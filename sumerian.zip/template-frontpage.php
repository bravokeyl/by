<?php
/**
 *Template Name: Frontpage
 */

get_header(); ?>

	<div id="content" class="site-content">
		<main id="main" class="site-main" role="main">
            <?php

            do_action( 'sumerian_frontpage_before_section_parts' );

			if ( ! has_action( 'sumerian_frontpage_section_parts' ) ) {

				$sections = apply_filters( 'sumerian_frontpage_sections_order', array(
                    'features', 'about', 'services', 'videolightbox', 'gallery', 'counter', 'team',  'news', 'contact'
                ) );

				foreach ( $sections as $section ){
                    sumerian_load_section( $section );
				}

			} else {
				do_action( 'sumerian_frontpage_section_parts' );
			}

            do_action( 'sumerian_frontpage_after_section_parts' );

			?>
		</main><!-- #main -->
	</div><!-- #content -->

<?php get_footer(); ?>
